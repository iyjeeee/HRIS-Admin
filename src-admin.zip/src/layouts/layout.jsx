// layout.jsx — Admin HRIS Layout: sidebar + top navbar, wraps all protected pages
import React, { useState, useEffect } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Users, Building2, Briefcase,
  Fingerprint, FileText, Clock, CreditCard,
  CheckSquare, Megaphone, Calendar, Tag,
  DollarSign, Receipt, FileArchive, FolderCheck,
  BarChart2, ShieldCheck, AlignLeft, Bell,
  User, LogOut, ChevronDown
} from 'lucide-react';

// ─── Page title map — path → display title in navbar ────────────────────────
const PAGE_TITLES = {
  '/dashboard':          'Dashboard',
  '/employees':          'Employees',
  '/departments':        'Departments',
  '/job-positions':      'Job Positions',
  '/attendance':         'Attendance',
  '/leave-requests':     'Leave Requests',
  '/overtime-requests':  'Overtime Requests',
  '/leave-credits':      'Leave Credits',
  '/tasks':              'Tasks',
  '/announcements':      'Announcements',
  '/calendar':           'Calendar',
  '/event-type':         'Event Types',
  '/payroll-periods':    'Payroll Periods',
  '/payslips':           'Payslips',
  '/employee-documents': 'Employee Documents',
  '/doc-requirements':   'Document Requirements',
  '/reports':            'Reports',
  '/role-permission':    'Roles & Permissions',
  '/audit-logs':         'Audit Logs',
  '/notifications':      'Notifications',
  '/profile':            'Profile',
};

const Layout = () => {
  const location = useLocation();
  const headerTitle = PAGE_TITLES[location.pathname] || '';

  // Notification dropdown open/close
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);

  // Expandable section states — auto-open if current path is inside group
  const empMgmtRoutes    = ['/employees', '/departments', '/job-positions'];
  const attLeaveRoutes   = ['/attendance', '/leave-requests', '/overtime-requests', '/leave-credits'];
  const tasksAnnRoutes   = ['/tasks', '/announcements'];
  const calRoutes        = ['/calendar', '/event-type'];
  const payrollRoutes    = ['/payroll-periods', '/payslips'];
  const docsRoutes       = ['/employee-documents', '/doc-requirements'];
  const systemRoutes     = ['/role-permission', '/audit-logs', '/notifications'];

  const inGroup = (routes) => routes.includes(location.pathname);

  const [empExpanded,    setEmpExpanded]    = useState(inGroup(empMgmtRoutes));
  const [attExpanded,    setAttExpanded]    = useState(inGroup(attLeaveRoutes));
  const [tasksExpanded,  setTasksExpanded]  = useState(inGroup(tasksAnnRoutes));
  const [calExpanded,    setCalExpanded]    = useState(inGroup(calRoutes));
  const [payExpanded,    setPayExpanded]    = useState(inGroup(payrollRoutes));
  const [docsExpanded,   setDocsExpanded]   = useState(inGroup(docsRoutes));
  const [sysExpanded,    setSysExpanded]    = useState(inGroup(systemRoutes));

  // Keep groups open when navigating within them
  useEffect(() => {
    if (inGroup(empMgmtRoutes))  setEmpExpanded(true);
    if (inGroup(attLeaveRoutes)) setAttExpanded(true);
    if (inGroup(tasksAnnRoutes)) setTasksExpanded(true);
    if (inGroup(calRoutes))      setCalExpanded(true);
    if (inGroup(payrollRoutes))  setPayExpanded(true);
    if (inGroup(docsRoutes))     setDocsExpanded(true);
    if (inGroup(systemRoutes))   setSysExpanded(true);
  }, [location.pathname]);

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-gray-900">

      {/* ═══════════ SIDEBAR ═══════════ */}
      <div className="w-56 bg-white flex flex-col h-full shrink-0 border-r border-gray-100">
        <div className="flex-1 overflow-y-auto scrollbar-thin">

          {/* Brand — text only, no icon per spec */}
          <div className="px-4 pt-6 pb-3">
            <div className="flex items-center gap-1.5">
              {/* Yellow HRIS accent text */}
              <span className="text-yellow-400 font-black text-base tracking-tight">HRIS</span>
              <span className="font-black text-base tracking-tight text-gray-900">HS SYSTEM</span>
            </div>
            {/* Admin portal sub-label */}
            <p className="text-[9px] text-gray-400 font-semibold tracking-widest uppercase mt-0.5">Admin Portal</p>
          </div>

          <div className="px-3 pb-4">

            {/* ── MAIN ── */}
            <SectionLabel label="MAIN" />
            <nav className="space-y-0.5">
              <SidebarLink to="/dashboard" icon={<LayoutDashboard size={15} />} label="Dashboard" />
            </nav>

            {/* ── EMPLOYEE MANAGEMENT ── */}
            <SectionLabel label="EMPLOYEE MANAGEMENT" />
            <nav className="space-y-0.5">
              <ExpandGroup
                label="Employees"    icon={<Users size={15} />}
                expanded={empExpanded} onToggle={() => setEmpExpanded(v => !v)}
                active={inGroup(empMgmtRoutes)}
              >
                <SubNavLink to="/employees"    label="Employees" />
                <SubNavLink to="/departments"  label="Departments" />
                <SubNavLink to="/job-positions" label="Job Positions" />
              </ExpandGroup>
            </nav>

            {/* ── ATTENDANCE & LEAVE ── */}
            <SectionLabel label="ATTENDANCE & LEAVE" />
            <nav className="space-y-0.5">
              <ExpandGroup
                label="Attendance"   icon={<Fingerprint size={15} />}
                expanded={attExpanded} onToggle={() => setAttExpanded(v => !v)}
                active={inGroup(attLeaveRoutes)}
              >
                <SubNavLink to="/attendance"        label="Attendance" />
                <SubNavLink to="/leave-requests"    label="Leave Requests" />
                <SubNavLink to="/overtime-requests" label="Overtime Requests" />
                <SubNavLink to="/leave-credits"     label="Leave Credits" />
              </ExpandGroup>
            </nav>

            {/* ── TASKS & ANNOUNCEMENTS ── */}
            <SectionLabel label="TASKS & ANNOUNCEMENTS" />
            <nav className="space-y-0.5">
              <SidebarLink to="/tasks"         icon={<CheckSquare size={15} />} label="Tasks" />
              <SidebarLink to="/announcements" icon={<Megaphone size={15} />}   label="Announcements" />
            </nav>

            {/* ── CALENDAR & EVENTS ── */}
            <SectionLabel label="CALENDAR & EVENTS" />
            <nav className="space-y-0.5">
              <SidebarLink to="/calendar"   icon={<Calendar size={15} />} label="Calendar" />
              <SidebarLink to="/event-type" icon={<Tag size={15} />}      label="Event Type" />
            </nav>

            {/* ── PAYROLL ── */}
            <SectionLabel label="PAYROLL" />
            <nav className="space-y-0.5">
              <SidebarLink to="/payroll-periods" icon={<DollarSign size={15} />} label="Payroll Periods" />
              <SidebarLink to="/payslips"        icon={<Receipt size={15} />}    label="Payslips" />
            </nav>

            {/* ── DOCUMENTS ── */}
            <SectionLabel label="DOCUMENTS" />
            <nav className="space-y-0.5">
              <SidebarLink to="/employee-documents" icon={<FileArchive size={15} />}  label="Employee Documents" />
              <SidebarLink to="/doc-requirements"   icon={<FolderCheck size={15} />}  label="Doc Requirements" />
            </nav>

            {/* ── REPORTS ── */}
            <SectionLabel label="REPORTS" />
            <nav className="space-y-0.5">
              <SidebarLink to="/reports" icon={<BarChart2 size={15} />} label="Reports" />
            </nav>

            {/* ── SYSTEM ── */}
            <SectionLabel label="SYSTEM" />
            <nav className="space-y-0.5">
              <SidebarLink to="/role-permission" icon={<ShieldCheck size={15} />} label="Role Permission" />
              <SidebarLink to="/audit-logs"      icon={<AlignLeft size={15} />}   label="Audit Logs" />
              <SidebarLink to="/notifications"   icon={<Bell size={15} />}        label="Notifications" />
            </nav>

          </div>
        </div>

        {/* ── Sidebar Footer ── */}
        <div className="border-t border-gray-100 bg-white shrink-0 p-2">
          {/* Admin user info row */}
          <div className="flex items-center gap-2.5 px-2 py-1.5 mb-1">
            {/* Avatar with initials */}
            <div className="w-7 h-7 bg-yellow-400 rounded-full flex items-center justify-center text-black font-black text-[10px] shrink-0">
              GM
            </div>
            <div className="min-w-0">
              <p className="font-bold text-xs leading-tight truncate">John Doe</p>
              <p className="text-[9px] text-gray-400 truncate">Project Management Head</p>
            </div>
            {/* Online dot */}
            <div className="w-2 h-2 bg-green-500 rounded-full ml-auto shrink-0"></div>
          </div>
          <nav className="space-y-0.5 px-1">
            <SidebarLink to="/profile" icon={<User size={15} />}   label="Profile" />
            <SidebarLink to="/"        icon={<LogOut size={15} />}  label="Log Out" />
          </nav>
        </div>
      </div>

      {/* ═══════════ MAIN CONTENT ═══════════ */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden min-w-0">

        {/* Top Navbar */}
        <header className="h-14 bg-white flex items-center justify-between px-6 shrink-0 border-b border-gray-100 z-40">
          <h1 className="text-base font-bold text-gray-800 tracking-tight">{headerTitle}</h1>
          <div className="flex items-center gap-4">
            {/* Live clock */}
            <LiveClock />
            {/* Notification bell */}
            <div className="relative">
              <button
                onClick={() => setIsNotificationOpen(!isNotificationOpen)}
                className="text-gray-500 hover:text-black transition-colors relative cursor-pointer p-1"
              >
                <Bell size={20} />
                {/* Unread indicator dot */}
                <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-red-500 rounded-full border border-white"></span>
              </button>

              {/* Notification dropdown */}
              {isNotificationOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setIsNotificationOpen(false)} />
                  <div className="absolute right-0 mt-2 w-80 bg-white border border-gray-200 rounded-xl shadow-xl z-20 overflow-hidden">
                    <div className="p-3.5 border-b border-gray-100 flex justify-between items-center">
                      <h3 className="font-bold text-sm text-gray-800">Notifications</h3>
                      <span className="text-[10px] bg-yellow-400 px-2 py-0.5 rounded-full font-bold">3 NEW</span>
                    </div>
                    <div className="max-h-72 overflow-y-auto">
                      <NotifItem title="New Leave Request — John Doe (Vacation)"  time="10 min ago"  type="Leave" />
                      <NotifItem title="Overtime Approval Pending — 3 employees"  time="1 hour ago"  type="Overtime" />
                      <NotifItem title="Payroll Cutoff Reminder — March 31, 2026" time="3 hours ago" type="Payroll" />
                    </div>
                    <button className="w-full py-2.5 text-xs text-gray-500 hover:text-black hover:bg-gray-50 transition-colors font-medium border-t border-gray-100 cursor-pointer">
                      View all notifications
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page content area */}
        <main className="flex-1 overflow-y-auto p-6 bg-gray-50">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

// ─── Live clock ──────────────────────────────────────────────────────────────
const LiveClock = () => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000); // tick every second
    return () => clearInterval(id);
  }, []);
  const date = time.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const t    = time.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true });
  return (
    <div className="text-gray-500 text-xs hidden md:block">
      {date} <span className="font-bold text-black ml-1">{t}</span>
    </div>
  );
};

// ─── Section label (small caps divider in sidebar) ───────────────────────────
const SectionLabel = ({ label }) => (
  <p className="text-[9px] text-gray-400 font-bold tracking-widest uppercase px-2 mt-4 mb-1">{label}</p>
);

// ─── Primary sidebar NavLink ─────────────────────────────────────────────────
const SidebarLink = ({ to, icon, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] transition-colors ${
        isActive
          ? 'bg-yellow-400 text-black font-bold'
          : 'text-gray-600 hover:bg-gray-50 hover:text-black font-medium'
      }`
    }
  >
    {icon}
    <span>{label}</span>
  </NavLink>
);

// ─── Expandable group button with sub-links ───────────────────────────────────
const ExpandGroup = ({ label, icon, expanded, onToggle, active, children }) => (
  <div>
    <button
      onClick={onToggle}
      className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] transition-colors cursor-pointer ${
        active
          ? 'bg-yellow-400 text-black font-bold'
          : 'text-gray-600 hover:bg-gray-50 hover:text-black font-medium'
      }`}
    >
      {icon}
      <span className="flex-1 text-left">{label}</span>
      {/* Chevron rotates when open */}
      <ChevronDown size={13} className={`transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`} />
    </button>
    {expanded && (
      <div className="ml-6 mt-0.5 mb-1 space-y-0.5 border-l-2 border-gray-100 pl-2">
        {children}
      </div>
    )}
  </div>
);

// ─── Sub-nav link inside expandable group ────────────────────────────────────
const SubNavLink = ({ to, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `block text-[12px] py-1.5 px-2 rounded-md transition-colors ${
        isActive
          ? 'text-black font-bold bg-yellow-100'
          : 'text-gray-500 hover:text-gray-900 hover:bg-gray-50'
      }`
    }
  >
    {label}
  </NavLink>
);

// ─── Notification dropdown item ──────────────────────────────────────────────
const NotifItem = ({ title, time, type }) => (
  <div className="p-3.5 border-b border-gray-50 hover:bg-gray-50 cursor-pointer transition-colors group">
    <div className="flex items-center gap-2 mb-1">
      <span className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
        type === 'Leave'    ? 'bg-blue-100 text-blue-600'     :
        type === 'Overtime' ? 'bg-purple-100 text-purple-600' :
                              'bg-green-100 text-green-600'
      }`}>{type}</span>
      <span className="text-[10px] text-gray-400">{time}</span>
    </div>
    <p className="text-xs text-gray-700 leading-snug group-hover:text-black">{title}</p>
  </div>
);

export default Layout;
